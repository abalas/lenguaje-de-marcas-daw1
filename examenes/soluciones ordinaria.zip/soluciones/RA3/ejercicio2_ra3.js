// guardará la posición de la bolita entre 0 y 2
let posicionBolita;
// cuando lo pongamos a True el juego termina
let juegoTerminado = false;
        
function iniciarJuego() {          
	// Nueva posición aleatoria (0, 1 o 2)
   posicionBolita = Math.floor(Math.random() * 3);
   document.getElementById('mensaje').innerHTML = "¿Sabes dónde está la bolita?";
   }

function verificar(cubilete, posicion) {
	// Si no hemos encontrado aún la bolita
	if(juegoTerminado == false){
      // Si la posición que hemos enviado con la función coincide con el número aleatorio hemos ganado      
   	if(posicion == posicionBolita) {
			cubilete.className = 'ganador';
      	cubilete.innerHTML = 'O';
      	document.getElementById('mensaje').innerHTML = '¡La encontraste! ¡Has ganado!';
      	juegoTerminado = true;
		} else {
			// si no, seguimos jugando
   		cubilete.className = 'error';
      	cubilete.innerHTML = 'X';
      	document.getElementById('mensaje').innerHTML = "¡Fallaste! Intentalo de nuevo";
     }
	}
	else
		alert("El juego ha terminado")
}

