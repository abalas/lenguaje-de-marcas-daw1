	function validarIBAN() {
    ibanInput = document.getElementById('iban').value
    resultado = document.getElementById('resultado');
    
    /* Eliminamos todos los espacios en blanco */
    temporal=ibanInput
    ibanInput=""
    for(i=0; i<temporal.length; i++)
    	if(temporal[i]!=" ")
    		ibanInput+=temporal[i]   
    
	// convertimos a mayúsculas para que quede mas bonito   		
    ibanInput=ibanInput.toUpperCase();
   
   // Limpiamos mensajes previos
    resultado.innerHTML = '';

    // Validación de longitud
    if (ibanInput.length !== 24) {
      mostrarError("Longitud incorrecta. El IBAN español debe tener 24 caracteres");
      return;
    }

    // Extraer componentes. Si conoces la función substring es muy fácil. Si no, hay que hacerlo manualmente.
    // He hecho una función que se llama trozodecadena que lo hace y llamo a una o a otra indistintamente
    // Lo suyo, claro, sería siempre usar la misma
    const pais = trozodecadena(ibanInput,0,2)
    const numeros = ibanInput.substring(2,24)
    const dc =  trozodecadena(ibanInput,2, 4)
    const entidad = ibanInput.substring(4, 8);
    const sucursal = ibanInput.substring(8, 12);
    const dcCuenta = ibanInput.substring(12, 14);
    const numeroCuenta = trozodecadena(ibanInput,14,24)

    // Empezamos con las validaciones. Primero los dos caracteres deben de ser letras
    // Me he hecho una función sencillita para ello aunque hay otras formas
    if (!esLetra(pais[0]) || !esLetra(pais[1]))
      mostrarError("Los dos primeros caracteres deben ser letras");
    // El resto deben de ser números
    else if (isNaN(Number(numeros)) == true)
      mostrarError("Los 22 últimos dígitos deben de ser números");
    // Y si lo cumple todo, es correcto
 	 else{
   	// Mostrar resultados
    	resultado.className = 'valido';
    	
    	/* Compongo el mensaje que voy a dar en HTML. Lo hago linea a linea
    		para que se entienda mejor, pero podría hacerlo de una vez */
    	informacion = "<strong>IBAN válido</strong><div class='detalles'>"
    	informacion += "<p>País: " + pais + "</p>"
    	informacion += "<p>Dígitos de control: " + dc + "</p>"
    	informacion += "<p>Entidad: " + entidad + "</p>"
    	informacion += "<p>Sucursal: " + sucursal + "</p>"
    	informacion += "<p>DC cuenta: " + dcCuenta + "</p>"
    	informacion += "<p>Número de cuenta: " + numeroCuenta + "</p></div>"
      					
    	resultado.innerHTML = informacion
  		}
  	}

// Para validar si un caracter es una letra mayúsculas. No incluyo la Ñ, pero sería fácil hacerlo...
function esLetra(c) {
	correcto = true
   if(c<= 'A' || c >= 'Z')
   	correcto = false
   return correcto
}

// Me hago una función para mostrar los errores. Así si quiero puedo incluir mas en el futuro de forma fácil
function mostrarError(mensaje) {
	const resultado = document.getElementById('resultado');
	resultado.className = 'invalido';
	resultado.innerHTML = `<strong>Error:</strong> ${mensaje}`;
}
  
function trozodecadena(cadena, inicio, fin){
	subcadena=""
	for(i=inicio; i<fin; i++)
		subcadena+=cadena[i]
	return subcadena  
  	}
