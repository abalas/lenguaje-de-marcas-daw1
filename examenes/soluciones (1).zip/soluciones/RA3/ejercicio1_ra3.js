let veces = prompt("¿Cuantos lanzamientos he de hacer?")

let num = parseInt(veces)
let num2 = parseFloat(veces)
let caras = 0
let contador1 = 0		
let contador2 = 0
		
if (isNaN(num) == true)
	alert("Eso no parece un número")		
else if(num != num2 )
	alert("No puedes usar un número con decimales")
else if (num == 0)
	alert("Deberías de hacer al menos un lanzamiento, no?")
else{
	for(i=0; i<num;i++){
		tirada = Math.floor(Math.random()*2)
		contador1 += 1
		contador2 += 1
		if(tirada == 0){
			caras +=1
			tiradas.innerHTML = tiradas.innerHTML + "<span class='azul'>O</span>"
			}	
		else			
			tiradas.innerHTML = tiradas.innerHTML + "<span class='rojo'>X</span>"
			if(contador2 == 30){
				contador1 = 0
				contador2 = 0
				tiradas.innerHTML = tiradas.innerHTML + "<br/>"
			}
			else if(contador1 == 10){
				contador1 = 0
				tiradas.innerHTML = tiradas.innerHTML + " "
			}		
		}
	mensaje.innerHTML = "Después de " + num + " lanzamientos de moneda han salido " + caras + " caras y " + (num-caras) + " cruces"
	}