let turno = "azul"
let contador = 1
	
function eligeturno(){
	eleccion = prompt("Escribe azul o rojo para ver quien empieza")
	if(eleccion == "azul")
		turno = "azul"
	else if(eleccion == "rojo")
		turno = "rojo"
	else 
		alert("Elección no valida. Empieza el azul")
	mensaje.innerHTML = "Turno " + contador + ". Empieza el color " + turno
}
	
function colorea(celda){
	if(contador == 17)
		alert("Partida terminada. No hay mas celdas que marcar")
	else
		if(celda.className == "nada"){
			contador +=1
			if(turno=="azul"){
				turno="rojo"
				celda.className = "azul"
				celda.innerHTML = "X"
				}				
			else{
				turno = "azul"
				celda.className = "rojo"
				celda.innerHTML = "O"
				}	
			if(contador<17)
				mensaje.innerHTML = "Turno " + contador + ". Le toca al color " + turno
			else {
				mensaje.innerHTML = "Juego terminado. No hay mas turnos"
			}
		}
}